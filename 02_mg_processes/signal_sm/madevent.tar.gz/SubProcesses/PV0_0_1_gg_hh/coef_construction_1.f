      SUBROUTINE ML5_0_0_1_COEF_CONSTRUCTION_1(P,NHEL,H,IC)
C     
C     Modules
C     
      USE ML5_0_0_1_POLYNOMIAL_CONSTANTS
C     
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=4)
      INTEGER    NCOMB
      PARAMETER (NCOMB=4)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=30, NLOOPGROUPS=30, NCTAMPS=7)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=37)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=8,NLOOPWAVEFUNCS=50)
      REAL*8     ZERO
      PARAMETER (ZERO=0D0)
      REAL*16     MP__ZERO
      PARAMETER (MP__ZERO=0.0E0_16)
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=1)
C     
C     ARGUMENTS
C     
      REAL*8 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      COMPLEX*16 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)

      LOGICAL DUMMYFALSE
      DATA DUMMYFALSE/.FALSE./
C     
C     GLOBAL VARIABLES
C     
      INCLUDE 'coupl.inc'
      INCLUDE 'mp_coupl.inc'

      INTEGER HELOFFSET
      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/ML5_0_0_1_FILTERS/GOODAMP,GOODHEL,HELOFFSET

      LOGICAL CHECKPHASE
      LOGICAL HELDOUBLECHECKED
      COMMON/ML5_0_0_1_INIT/CHECKPHASE, HELDOUBLECHECKED

      INTEGER SQSO_TARGET
      COMMON/ML5_0_0_1_SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/ML5_0_0_1_SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      INTEGER I_SO
      COMMON/ML5_0_0_1_I_SO/I_SO
      INTEGER I_LIB
      COMMON/ML5_0_0_1_I_LIB/I_LIB

      COMPLEX*16 W(20,NWAVEFUNCS)
      COMMON/ML5_0_0_1_W/W

      COMPLEX*16 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*16 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/ML5_0_0_1_WL/WL,PL

      COMPLEX*16 AMPL(3,NLOOPAMPS)
      COMMON/ML5_0_0_1_AMPL/AMPL

C     
C     ----------
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.LOOP_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

C     Coefficient construction for loop diagram with ID 1
      CALL FFV87L1_2(PL(0,0),W(1,1),GC_11,MDL_MT,MDL_WT,PL(0,1),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_0_1(WL(1,0,1,0),4,COEFS,4,4,WL(1,0,1,1))
      CALL FFV87L1_2(PL(0,1),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,2),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,1),4,COEFS,4,4,WL(1,0,1,2))
      CALL FFSS26L1_2(PL(0,2),W(1,3),W(1,4),GC_1822,MDL_MT,MDL_WT,PL(0
     $ ,3),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,3))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,3),3,4,1,1,1,8)
C     Coefficient construction for loop diagram with ID 2
      CALL FFS37L1_2(PL(0,2),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,4),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,4))
      CALL FFS37L1_2(PL(0,4),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,5)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,4),4,COEFS,4,4,WL(1,0,1,5))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,5),4,4,2,1,1,9)
C     Coefficient construction for loop diagram with ID 3
      CALL FFS37L1_2(PL(0,2),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,6)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,6))
      CALL FFS37L1_2(PL(0,6),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,7),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,6),4,COEFS,4,4,WL(1,0,1,7))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,7),4,4,3,1,1,10)
C     Coefficient construction for loop diagram with ID 4
      CALL FFS37L1_2(PL(0,4),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,8),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,4),4,COEFS,4,4,WL(1,0,1,8))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,8),4,4,4,1,1,11)
C     Coefficient construction for loop diagram with ID 5
      CALL FFS37L1_2(PL(0,2),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,9),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,9))
      CALL FFS37L1_2(PL(0,9),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,10)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,9),4,COEFS,4,4,WL(1,0,1,10)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,10),4,4,5,1,1,12)
C     Coefficient construction for loop diagram with ID 6
      CALL FFS37L1_2(PL(0,2),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,11)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,11)
     $ )
      CALL FFS37L1_2(PL(0,11),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,12)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,11),4,COEFS,4,4,WL(1,0,1
     $ ,12))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,12),4,4,6,1,1,13)
C     Coefficient construction for loop diagram with ID 7
      CALL FFS37L1_2(PL(0,9),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,13)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,9),4,COEFS,4,4,WL(1,0,1,13)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,13),4,4,7,1,1,14)
C     Coefficient construction for loop diagram with ID 8
      CALL FFS37L1_2(PL(0,2),W(1,5),GC_1842,MDL_MT,MDL_WT,PL(0,14)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,14)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,14),3,4,8,1,1,15)
C     Coefficient construction for loop diagram with ID 9
      CALL FFS37L1_2(PL(0,2),W(1,5),GC_546,MDL_MT,MDL_WT,PL(0,15)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,15)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,15),3,4,9,1,1,16)
C     Coefficient construction for loop diagram with ID 10
      CALL FFS37L1_2(PL(0,2),W(1,6),GC_546,MDL_MT,MDL_WT,PL(0,16)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,16)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,16),3,4,10,1,1,17)
C     Coefficient construction for loop diagram with ID 11
      CALL FFS37L1_2(PL(0,2),W(1,7),GC_546,MDL_MT,MDL_WT,PL(0,17)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,17)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,17),3,4,11,1,1,18)
C     Coefficient construction for loop diagram with ID 12
      CALL FFS37L1_2(PL(0,2),W(1,8),GC_546,MDL_MT,MDL_WT,PL(0,18)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,2),4,COEFS,4,4,WL(1,0,1,18)
     $ )
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,18),3,4,12,1,1,19)
C     Coefficient construction for loop diagram with ID 13
      CALL FFV87L2_1(PL(0,0),W(1,1),GC_11,MDL_MT,MDL_WT,PL(0,19),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_0_1(WL(1,0,1,0),4,COEFS,4,4,WL(1,0,1,19)
     $ )
      CALL FFV87L2_1(PL(0,19),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,20)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,19),4,COEFS,4,4,WL(1,0,1
     $ ,20))
      CALL FFS37L2_1(PL(0,20),W(1,5),GC_1842,MDL_MT,MDL_WT,PL(0,21)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,21))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,21),3,4,13,1,1,20)
C     Coefficient construction for loop diagram with ID 14
      CALL FFS37L2_1(PL(0,20),W(1,5),GC_546,MDL_MT,MDL_WT,PL(0,22)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,22))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,22),3,4,14,1,1,21)
C     Coefficient construction for loop diagram with ID 15
      CALL FFS37L2_1(PL(0,20),W(1,6),GC_546,MDL_MT,MDL_WT,PL(0,23)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,23))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,23),3,4,15,1,1,22)
C     Coefficient construction for loop diagram with ID 16
      CALL FFS37L2_1(PL(0,20),W(1,7),GC_546,MDL_MT,MDL_WT,PL(0,24)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,24))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,24),3,4,16,1,1,23)
C     Coefficient construction for loop diagram with ID 17
      CALL FFS37L2_1(PL(0,20),W(1,8),GC_546,MDL_MT,MDL_WT,PL(0,25)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,25))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,25),3,4,17,1,1,24)
C     Coefficient construction for loop diagram with ID 18
      CALL FFS37L2_1(PL(0,20),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,26)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,26))
      CALL FFS37L2_1(PL(0,26),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,27)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,26),4,COEFS,4,4,WL(1,0,1
     $ ,27))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,27),4,4,18,1,1,25)
C     Coefficient construction for loop diagram with ID 19
      CALL FFS37L1_2(PL(0,1),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,28)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,1),4,COEFS,4,4,WL(1,0,1,28)
     $ )
      CALL FFV87L1_2(PL(0,28),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,29)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,28),4,COEFS,4,4,WL(1,0,1
     $ ,29))
      CALL FFS37L1_2(PL(0,29),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,30)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,29),4,COEFS,4,4,WL(1,0,1
     $ ,30))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,30),4,4,19,1,1,26)
C     Coefficient construction for loop diagram with ID 20
      CALL FFS37L2_1(PL(0,20),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,31)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,31))
      CALL FFS37L2_1(PL(0,31),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,32)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,31),4,COEFS,4,4,WL(1,0,1
     $ ,32))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,32),4,4,20,1,1,27)
C     Coefficient construction for loop diagram with ID 21
      CALL FFS37L2_1(PL(0,26),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,33)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,26),4,COEFS,4,4,WL(1,0,1
     $ ,33))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,33),4,4,21,1,1,28)
C     Coefficient construction for loop diagram with ID 22
      CALL FFS37L1_2(PL(0,1),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,34)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,1),4,COEFS,4,4,WL(1,0,1,34)
     $ )
      CALL FFV87L1_2(PL(0,34),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,35)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,34),4,COEFS,4,4,WL(1,0,1
     $ ,35))
      CALL FFS37L1_2(PL(0,35),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,36)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,35),4,COEFS,4,4,WL(1,0,1
     $ ,36))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,36),4,4,22,1,1,29)
C     Coefficient construction for loop diagram with ID 23
      CALL FFS37L1_2(PL(0,35),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,37)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,35),4,COEFS,4,4,WL(1,0,1
     $ ,37))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,37),4,4,23,1,1,30)
C     Coefficient construction for loop diagram with ID 24
      CALL FFS37L2_1(PL(0,20),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,38)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,38))
      CALL FFS37L2_1(PL(0,38),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,39)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,38),4,COEFS,4,4,WL(1,0,1
     $ ,39))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,39),4,4,24,1,1,31)
C     Coefficient construction for loop diagram with ID 25
      CALL FFS37L2_1(PL(0,19),W(1,3),GC_546,MDL_MT,MDL_WT,PL(0,40)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,19),4,COEFS,4,4,WL(1,0,1
     $ ,40))
      CALL FFV87L2_1(PL(0,40),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,41)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,40),4,COEFS,4,4,WL(1,0,1
     $ ,41))
      CALL FFS37L2_1(PL(0,41),W(1,4),GC_1842,MDL_MT,MDL_WT,PL(0,42)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,41),4,COEFS,4,4,WL(1,0,1
     $ ,42))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,42),4,4,25,1,1,32)
C     Coefficient construction for loop diagram with ID 26
      CALL FFS37L2_1(PL(0,20),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,43)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,43))
      CALL FFS37L2_1(PL(0,43),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,44)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,43),4,COEFS,4,4,WL(1,0,1
     $ ,44))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,44),4,4,26,1,1,33)
C     Coefficient construction for loop diagram with ID 27
      CALL FFS37L2_1(PL(0,38),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,45)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,38),4,COEFS,4,4,WL(1,0,1
     $ ,45))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,45),4,4,27,1,1,34)
C     Coefficient construction for loop diagram with ID 28
      CALL FFS37L2_1(PL(0,19),W(1,3),GC_1842,MDL_MT,MDL_WT,PL(0,46)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_1_1(WL(1,0,1,19),4,COEFS,4,4,WL(1,0,1
     $ ,46))
      CALL FFV87L2_1(PL(0,46),W(1,2),GC_11,MDL_MT,MDL_WT,PL(0,47)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,46),4,COEFS,4,4,WL(1,0,1
     $ ,47))
      CALL FFS37L2_1(PL(0,47),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,48)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,47),4,COEFS,4,4,WL(1,0,1
     $ ,48))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,48),4,4,28,1,1,35)
C     Coefficient construction for loop diagram with ID 29
      CALL FFS37L2_1(PL(0,41),W(1,4),GC_546,MDL_MT,MDL_WT,PL(0,49)
     $ ,COEFS)
      CALL ML5_0_0_1_UPDATE_WL_3_1(WL(1,0,1,41),4,COEFS,4,4,WL(1,0,1
     $ ,49))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,49),4,4,29,1,1,36)
C     Coefficient construction for loop diagram with ID 30
      CALL FFSS26L2_1(PL(0,20),W(1,3),W(1,4),GC_1822,MDL_MT,MDL_WT
     $ ,PL(0,50),COEFS)
      CALL ML5_0_0_1_UPDATE_WL_2_1(WL(1,0,1,20),4,COEFS,4,4,WL(1,0,1
     $ ,50))
      CALL ML5_0_0_1_CREATE_LOOP_COEFS(WL(1,0,1,50),3,4,30,1,1,37)
C     At this point, all loop coefficients needed for (QCD=4), i.e. of
C      split order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 4000

      GOTO 1001
 4000 CONTINUE
      LOOP_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END

